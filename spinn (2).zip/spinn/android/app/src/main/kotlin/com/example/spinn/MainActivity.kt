package com.example.spinn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
